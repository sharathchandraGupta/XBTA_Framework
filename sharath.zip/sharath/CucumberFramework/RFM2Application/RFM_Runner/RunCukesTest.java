//package demotest.demo;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)

@CucumberOptions(tags = { "@RunAll" }, plugin = { "pretty" },
		features = "src/RFM_Feature")//, glue = "StepDefinitions")

public class RunCukesTest {

}
