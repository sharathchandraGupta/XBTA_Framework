//package demotest.demo;
	import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.*;
import cucumber.api.*;
	//import implementation.*;
	
public class MI_StepDef {
	
	WebDriver driver = new FirefoxDriver();
	@Before
	public void BeforeRunningScenario(){
		//WebDriver driver = new FirefoxDriver();
		driver.get("https://rfm2mig4e.mcd.com/rfm2OnlineApp/rfmLogin.action");
	}
	
	@After
	public void AfterRunningScenario(){
		driver.close();
	}

	@Given("^The user has valid credentials$")
	public void the_user_has_valid_credentials() throws Throwable {
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_UsernameRegular")).sendKeys("e0058916");
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_PasswordTextBoxRegular")).sendKeys("Bigmac@23");
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSubmit")).click();
		
	    throw new PendingException();
	}
	
	@Given("^browser should launch$")
	public void browser_should_launch() throws Throwable {

		//WebDriver driver = new FirefoxDriver();
		//driver.get("https://rfm2mig4e.mcd.com/rfm2OnlineApp/rfmLogin.action");
	    throw new PendingException();
	}

	@When("^User tries to access the application$")
	public void user_tries_to_access_the_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User should be able to access the application\\.$")
	public void user_should_be_able_to_access_the_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User should be able to navigate to the desired <Navigation Page> page$")
	public void user_should_be_able_to_navigate_to_the_desired_Navigation_Page_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^The Page title should be correct\\.$")
	public void the_Page_title_should_be_correct(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    throw new PendingException();
	}

	@Given("^The Menu Item Number range is between (\\d+)-(\\d+)$")
	public void the_Menu_Item_Number_range_is_between(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User will Navigate to Master Menu Item List Page$")
	public void user_will_Navigate_to_Master_Menu_Item_List_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User will Click on the New Menu Item button$")
	public void user_will_Click_on_the_New_Menu_Item_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will be navigated to the New Window with name Add New Menu Item$")
	public void user_will_be_navigated_to_the_New_Window_with_name_Add_New_Menu_Item() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User will Enter the Menu Item Name$")
	public void user_will_Enter_the_Menu_Item_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User will Enter the Menu Item Number$")
	public void user_will_Enter_the_Menu_Item_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User will Click on Next button$")
	public void user_will_Click_on_Next_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Verify that User will be navigated to the Manage Menu Item page$")
	public void verify_that_User_will_be_navigated_to_the_Manage_Menu_Item_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Select the Menu Item Type$")
	public void user_will_Select_the_Menu_Item_Type() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Select the Menu Item Class$")
	public void user_will_Select_the_Menu_Item_Class() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Select the Menu Item Category$")
	public void user_will_Select_the_Menu_Item_Category() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Select the Family Group$")
	public void user_will_Select_the_Family_Group() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Select the Day Part Code$")
	public void user_will_Select_the_Day_Part_Code() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Enter the Long Name$")
	public void user_will_Enter_the_Long_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Enter the Short Name$")
	public void user_will_Enter_the_Short_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Enter the DT Name$")
	public void user_will_Enter_the_DT_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User will Click on the Save Button$")
	public void user_will_Click_on_the_Save_Button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Page will be reloaded$")
	public void page_will_be_reloaded() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Success Message should be Displayed$")
	public void success_Message_should_be_Displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user has successfully navigated to the the Restaurant Profile$")
	public void user_has_successfully_navigated_to_the_the_Restaurant_Profile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user checks if the Restaurant Link and Search are enabled$")
	public void user_checks_if_the_Restaurant_Link_and_Search_are_enabled() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user tries to click on the Restaurant Link$")
	public void user_tries_to_click_on_the_Restaurant_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user navigates back to the home Page$")
	public void user_navigates_back_to_the_home_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user has successfully navigated to the the Master Menu Item List$")
	public void user_has_successfully_navigated_to_the_the_Master_Menu_Item_List() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user checks if the Family Group and Search are enabled$")
	public void user_checks_if_the_Family_Group_and_Search_are_enabled() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user tries to click on the Family Group$")
	public void user_tries_to_click_on_the_Family_Group() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user has successfully navigated to the the Price Sets$")
	public void user_has_successfully_navigated_to_the_the_Price_Sets() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user checks if the Price Set Link and New Price Set are enabled$")
	public void user_checks_if_the_Price_Set_Link_and_New_Price_Set_are_enabled() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user tries to click on the Price Set Link$")
	public void user_tries_to_click_on_the_Price_Set_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters <Valid Criteria> search criteria$")
	public void user_enters_Valid_Criteria_search_criteria() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user click on search button$")
	public void user_click_on_search_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the search results should be displayed$")
	public void the_search_results_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user selects value from <Filter> drop down$")
	public void user_selects_value_from_Filter_drop_down() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user clicks on search button$")
	public void user_clicks_on_search_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^correct search results should be displayed\\.$")
	public void correct_search_results_should_be_displayed(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    throw new PendingException();
	}

}